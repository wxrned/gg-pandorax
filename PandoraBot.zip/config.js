module.exports = {
  token: process.env.TOKEN || null,
  mongo: process.env.MONGO || null,
  prefix: ",",

  vanityCode: "/pandorax",
  repRoleId: "1297968483123855431",
  repChannelId: "1340283722116890665",
};
